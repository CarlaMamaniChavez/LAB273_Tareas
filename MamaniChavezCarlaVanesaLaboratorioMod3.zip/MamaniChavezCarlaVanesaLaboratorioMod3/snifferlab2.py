from socket import *
import struct
import sys
import re

# Recibimos los datagramas
def banderas(n):
    V = {"Urgent Flag":"", "Acknowledgement Flag":"", "Push Flag":"", "Reset Flag":"", "Syncronise Flag":"", "Finish Flag":""}
    x = str(bin(n))
    x = x[2:len(x)]
    x = x.zfill(6)
    i = 0
    for f, v in V.items():
        v = x[i]
        i = i + 1
        print(f,":", v)
#Y primero recibimos los datos del socket, el método recvfrom en el módulo de socket
#nos ayuda a recibir todos los datos del socket. El parámetro pasado es el tamaño del
#búffer 65565 es el tamaño máximo del búffer.
def RecepData(s):
    data = ''
    try:
        data = s.recvfrom(65565)
    except timeout:
        data = ''
    except:
        print ("Ocurrio un error: ")
        sys.exc_info()
    return data[0]

#adquirimos el Tipo de Servicio de tamaño 8 bits
def obtenerTOS(data):
    #precedence permite indicar una procedencia.
    precedence = {0: "Routine", 1: "Priority", 2: "Immediate", 3: "Flash", 4: "Flash override", 5: "CRITIC/ECP",
                  6: "Internetwork control", 7: "Network control"}
    #delay, permite optimizar el retardo.              
    delay = {0: "Normal delay", 1: "Low delay"}
    #throughput, permite optimizar la velocidad eficaz.
    throughput = {0: "Normal throughput", 1: "High throughput"}
    #reliability, permite optimizar la fiabilidad.
    reliability = {0: "Normal reliability", 1: "High reliability"}
    # cost, permite optimizar el costo
    cost = {0: "Normal monetary cost", 1: "Minimize monetary cost"}

#adquirimos el 3er bit y se desplaza a la derecha
    D = data & 0x10
    D >>= 4
#adquirimos el 4to bit y se desplaza a la derecha
    T = data & 0x8
    T >>= 3
#adquirimos el 5to bit y se desplaza a la derecha
    R = data & 0x4
    R >>= 2
#adquirimos el 6to bit y se desplaza a la derecha
    M = data & 0x2
    M >>= 1
#el 7mo bit está vacío y no debe analizarse

    tabs = '\n\t\t\t'
    TOS = precedence[data >> 5] + tabs + delay[D] + tabs + throughput[T] + tabs + \
            reliability[R] + tabs + cost[M]
    return TOS

#Adquirimos los Flags: 3 bits
def obtenerFlags(data):
    #Tenemos los bit de reserva como flagR
    flagR = {0: "0 - Reserved bit"}
    #Fragmento si es necesario o No fragmentar como flagDF
    flagDF = {0: "0 - Fragment if necessary", 1: "1 - Do not fragment"}
    #Último fragmento o Más fragmentos como flagMF
    flagMF = {0: "0 - Last fragment", 1: "1 - More fragments"}

#adquirimos el 1er bit y se desplaza a la derecha
    R = data & 0x8000
    R >>= 15
#adquirimos el 2do bit y se desplaza a la derecha
    DF = data & 0x4000
    DF >>= 14
#adquirimos el 3er bit y se desplaza a la derecha
    MF = data & 0x2000
    MF >>= 13

    tabs = '\n\t\t\t'
    flags = flagR[R] + tabs + flagDF[DF] + tabs + flagMF[MF]
    return flags

#Adquirimos el protocolo: 8 bits
def obtenerProtocol(protocolNr):
    #capturamos los protocolos donde leemos el archivo protocolos.txt 
    protocolFile = open('protocol.txt', 'r')
    protocolData = protocolFile.read()
    protocol = re.findall(r'\n' + str(protocolNr) + ' (?:.)+\n', protocolData)
    if protocol:
        protocol = protocol[0]
        protocol = protocol.replace("\n", "")
        protocol = protocol.replace(str(protocolNr), "")
        protocol = protocol.lstrip()
        return protocol

    else:
        return 'no exite tal protocolo'

while(True):
    # gethostbyname recupera la información del host correspondiente
    #a un nombre de host de una base de datos de host.
    HOST = gethostbyname(gethostname())

    #creamos un socket sin procesar y vincularlo a la interfaz pública
    s = socket(AF_INET, SOCK_RAW, IPPROTO_IP)
    s.bind((HOST, 0))

    # Incluye encabezados IP
    s.setsockopt(IPPROTO_IP, IP_HDRINCL, 1)
    # Modo promiscuo habilitado
    s.ioctl(SIO_RCVALL, RCVALL_ON)

    #Recibimos los datos
    data = RecepData(s)

    # obtener el encabezado IP (los primeros 20 bytes) y descomprimirlos
    # B - carácter sin signo (1)
    # H - corto sin signo (2)
    # s - cadena
    unpackedData = struct.unpack('!BBHHHBBH4s4s' , data[0:20])

    version_IHL = unpackedData[0]
    version = version_IHL >> 4                  
    # Version IP
    IHL = version_IHL & 0xF                     
    # longitud del encabezado
    TOS = unpackedData[1]                       
    # tipo de servicio
    totalLength = unpackedData[2]
    ID = unpackedData[3]                        
    # ID
    flags = unpackedData[4]
    fragmentOffset = unpackedData[4] & 0x1FFF
    TTL = unpackedData[5]                       
    # TTL
    protocolNr = unpackedData[6]
    checksum = unpackedData[7]
    sourceAddress = inet_ntoa(unpackedData[8])
    destinationAddress = inet_ntoa(unpackedData[9])


    #Mostramos todos los campos de la cabecera de la IP
    print ("Se capturó un paquete IP con el tamaño %i" % (unpackedData[2]))
    print (data)
    print("\tIP Header")
    print ("IP Version: \t\t" + str(version))
    print ("IP Header Length (IHL): \t\t" + str(IHL*4) + " bytes")
    print ("Type of Service (TOS):\t" + obtenerTOS(TOS))
    print ("IP Total Length: \t\t\t" + str(totalLength))
    print ("Identification:\t\t\t" + str(hex(ID)) + " (" + str(ID) + ")")
    print( "flags:\t\t\t" + obtenerFlags(flags))
    print("Protocol: \t\t" + str(obtenerProtocol(protocolNr)))
    print( "TTL:\t\t\t" + str(TTL))
    print("Checksum:\t\t" + str(checksum))
    print("Source Address IP: \t\t\t" + sourceAddress)
    print("Destination Address IP: \t\t" + destinationAddress)
   
    #longitud del encabezado de Internet 
    #que es el número de palabras de 32 bits en el encabezado. 
    #Entonces, tenemos que multiplicar el IHL por 4 para obtener el tamaño del encabezado en bytes
    iph_length = IHL * 4
    tcp_header = data[iph_length:iph_length+20]

    #ahora descomprimirlos
    tcph = struct.unpack('!HHLLBBHHH' , tcp_header)
    # uint16_t
    source_port = tcph[0]   
    # uint16_t
    dest_port = 9000  
    # uint32_t   
    sequence = tcph[2]  
    # uint32_t    
    acknowledgement = tcph[3]
    # uint8_t
    doff_reserved = tcph[4]     
    tcph_length = doff_reserved >> 4
    #uint8_t
    tcph_flags = tcph[5] 
    #uint16_t           
    tcph_window_size = tcph[6]      
    #uint16_t
    tcph_checksum = tcph[7] 
    #uint16_t
    tcph_urgent_pointer = tcph[8]   
   
    print("\tTCP Header")
    #Source Port identifica el número de puerto de un programa de aplicación de origen.
    print("Source Port: ",source_port)
    #Destination Port: Identifica el número de puerto de un programa de aplicación de destino.
    print("Destination Port: ",dest_port)
    #Sequence Number: Especifica el número de secuencia del primer byte de datos de este segmento.
    print("Sequence Number: ",sequence)
    #Acknowledgment Number: Identifica la posición del byte más alto recibido.
    print("Acknowledge Number: ",acknowledgement)
    #Longitud del cabezal
    print("Header Length: ",tcph_length,'DWORDS or ',str(tcph_length*32//8) ,'bytes')
    #el valor del flag
    print("Flag Value: " + str(tcph_flags))
    banderas(tcph_flags)
    print("Urgent Flag: ",tcph_urgent_pointer)
    #Windows Size: Especifica la cantidad de datos que el destino está dispuesto a aceptar.
    print("Window Size:",tcph_window_size)
    #Checksum: Verifica la integridad de la cabecera y los datos de segmento.
    print("Checksum:",tcph_checksum)
   
    # modo promiscuo deshabilitado
    s.ioctl(SIO_RCVALL, RCVALL_OFF)