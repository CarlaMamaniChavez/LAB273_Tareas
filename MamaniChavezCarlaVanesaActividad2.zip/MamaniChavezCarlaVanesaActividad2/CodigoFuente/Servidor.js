// este modulo se crea y inicializa el servidor 
var http = require('http').createServer(Servidor);
// este modulo interactua con archivos locales es decir Fyle System
var fs = require ('fs');
// este modulo interactua con archivos externos 
var url = require ('url'); 
//Vamos a almacenar los tipos de documentos requeridos 
const TipoDocumento = {
//tipo Extensiones multipropósito de Correo de Internet 
//En los cuales en el ejercicio nos pide:
//	Tipo de documento html con la extension Multiproposito "text/html"
    'html' : "text/html",
//	Tipo de documento pdf con la extension Multiproposito"application/pdf"
    'pdf' : "application/pdf",
//	Tipo de documento json con la extension Multiproposito "application/json"
    'json' : "application/json",
//	Tipo de documento ascii con la extension Multiproposito "text/plain"
    'ascii' : "text/plain"
};
//funcion que realizare las peticiones del Servidor
//que son Solicitud y respuesta
function Servidor(solicitud,respuesta){
//en la variable cadena del modulo url lo analizamos con el parse y mandamos la solucitud del url
    var cadena = url.parse(solicitud.url,true,);
    //seleccionamos la ruta 
    var ruta = "."+cadena.pathname;
//el punto simboliza los directorio al que se quiere dirigir, lo concatenamos con la variable cadena y nombre de la ruta
    fs.access(ruta , fs.constants.F_OK , function(error){
 //De modulo FyleSystem  
        console.log(`${ruta} ${error ? "no existe" : "existe"}`);
    });

    fs.readFile(ruta, function(error,data){
  
  //si no encontramos el archivo, nos genera un error
        if(error){
            //denominaod 404 not found como texto plano 
            respuesta.writeHead(404 , {'Content-Type':'text/plain'});
            //retorna la funcion 
            return respuesta.end('404 - NOT FOUND');
        }
//creamos un vector del cual llama la ruta con respecto del directorio y despues lo extraemos
        const vec = ruta.split('.');
        //creamos la variable extension donde guardaremos el tamaño del vector
        const extension = vec[vec.length-1];
        //creamos el contenido donde guardaremos el tipo de documento en el vector de la extension
        const contendo = TipoDocumento[extension];
        //leemos del contenido que extraemos
        respuesta.writeHead(200, {'Content-Type': contendo});
        //respuesta escribimos los datos
        respuesta.write(data);
        //retornamos la respuesta
        return respuesta.end();

    })
};
http.listen(3000);
//se asigna el puerto 3000 para el servicio
console.log("escuchando desde el puerto 3000");